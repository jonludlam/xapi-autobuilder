#ifndef _POSIX_SYS_TCP_H_
#define _POSIX_SYS_TCP_H_

#include <lwip/tcp.h>

#endif /* _POSIX_SYS_TCP_H_ */
