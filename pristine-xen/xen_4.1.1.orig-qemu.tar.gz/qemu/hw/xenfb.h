#ifndef _XENFB_H_
#define _XENFB_H_

#include "hw.h"
#include <stdbool.h>
#include <sys/types.h>

extern const unsigned char atkbd_set2_keycode[512];
extern const unsigned char atkbd_unxlate_table[128];

#endif
